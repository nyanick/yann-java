/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package GPACAL;

/**
 *
 * @author YANIQUE
 */

//program to compute the sum of digits of an interger

import java.util.*;

public class Fxns{

    
    //this method will be use to calculate the gpa, multiplying it with the credit value
    public double GradeFrmMks(double g){
	double realGrade = 0;
                if(g>=80.0)
                    realGrade=4.0;
                else if(g>=70.0)
                    realGrade=3.50;
                else if(g>=60.0)
                    realGrade=3.00;
                else if(g>=55.0)
                    realGrade=2.50;
                else if(g>=50.0)
                    realGrade=2.00;
                else if(g>=45.0)
                    realGrade=1.50;
                else if(g>=40.0)
                    realGrade=1.00;
                else
                    realGrade=0.00;
             
		return realGrade;
	
	}
    //this is use to print the grades in the result
    public String getGrade(double k){
        String grade = "Err";
            if(k==4.00)
                grade ="A";
            if(k==3.50)
                grade ="B+";
            if(k==3.00)
                grade ="B";
            if(k==2.50)
                grade ="C+";
            if(k==2.00)
                grade ="C";
            if(k==1.50)
                grade ="D+";
            if(k==1.00)
                grade ="D-";
            if(k<1.00)
                grade ="F";
        
            return grade;
    }
    
    //method to calculate Gpa
    
    
}

